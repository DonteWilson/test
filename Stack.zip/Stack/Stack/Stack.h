#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <stack>
#include <string>
using namespace std;

class Node
{
public:
	Node(int);
	Node* next;
private:
	
	

};


class Stack
{
public:
	Node* top;

private:




};

void main()
{
	Node Top(1);
	Node Jungle(2);
	Node Mid(3);
	Node Adc(4);
	Node Support(5);

}






































#endif
