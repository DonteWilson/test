////////////////////////////////////////////////
//Donte Wilson
//9/29/15
//ADGP 105: Retro Game {110 hours}
////////////////////////////////////////////////
#ifndef MAP_H
#define MAP_H
#include <iostream>
#include <cstdlib>
using namespace std;
//class representing map
class Map
{
//public data set for map
public:
	//Constructor for Map
	Map();
	//Deconstructor for Map
	~Map();

	void generateMap();
	void generateMapfile();
	void PrintContents();
//private data set for map
};




#endif MAP_H
